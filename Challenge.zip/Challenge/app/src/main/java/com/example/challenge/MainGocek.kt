package com.example.challenge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainGocek : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_gocek)
    }
}